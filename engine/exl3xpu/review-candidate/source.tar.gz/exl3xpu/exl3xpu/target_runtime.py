"""Reviewed vLLM 0.30 port. Deliberately do not apply legacy runner/cache patches."""
import hashlib
import inspect
import textwrap
from pathlib import Path
import vllm
from vllm.logger import init_logger
from .gdn_rows import HostRows
from .gdn_target_patch import transformed_build

logger = init_logger('vllm.exl3xpu.port')
SOURCE_HASHES = {
    'v1/attention/backends/gdn_attn.py': 'd30bfce0df438e0d29d8a8744aeb9fb8e4bdcbca2410fde7afdb2a6cdb627f1b',
    'v1/worker/gpu/model_states/mamba_hybrid.py': '573e130ac5587d4822fabf97adad1ad0fda02ff83c5e70df879a5bb175ae845c',
    'platforms/xpu.py': '3736e6cba2a0d78b9bd93f6069f610e2b2725be00f398a6ad5672a9862d66285',
    'v1/core/single_type_kv_cache_manager.py': '0233531d85aeced9e57a38c76d83db970519c92902b7e55484390cb2b64985bf',
    'v1/worker/xpu_model_runner.py': '07fa0390d28f2b8c3c3c0019eb9c3b126e2397aea268ba47c889f06b423deb23',
    'v1/worker/xpu_worker.py': '711b56432506b58041cd86e71320c3960413f7bd61061990b66488421d81cfc3',
}


def install():
    from vllm.v1.attention.backends import gdn_attn
    cls = gdn_attn.GDNAttentionMetadataBuilder
    if getattr(cls, '_exl3_target_patched', False):
        return
    root = Path(vllm.__file__).parent
    actual = {f: hashlib.sha256((root/f).read_bytes()).hexdigest() for f in SOURCE_HASHES}
    if actual != SOURCE_HASHES:
        raise RuntimeError(f'Unknown target runtime for EXL3 port: {actual}')
    source, sites = transformed_build(textwrap.dedent(inspect.getsource(cls.build)))
    ns = dict(vars(gdn_attn), _Exl3HostRows=HostRows)
    exec(compile(source, f'<EXL3 target GDN {gdn_attn.__file__}>', 'exec'), ns)
    cls.build = ns['build']
    cls._exl3_target_patched = True
    logger.info('EXL3 target GDN semantic row selection: %s; V2 Mamba metadata uses this builder; '
                'native block64/sparse retirement retained; no V1 align or old attention override', sites)
    from . import attention_dispatch
    attention_dispatch.install()
