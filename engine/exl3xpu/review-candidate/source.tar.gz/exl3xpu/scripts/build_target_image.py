#!/usr/bin/env python3
"""Build and attest an isolated target candidate; never overwrite a candidate tag."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
BUILDER='sha256:ae6950731b3c031f812a95c0eb615a572239426440bf67fd1b3c9c9cbfce9eca'
BASE='sha256:ed1ebca756abb0e0832d11cd0db026dd7e86df094c6903efe7ae8afbdc290b68'
def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--tag',required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--native-artifacts',type=Path,help='Reuse only an ABI/source/hash-verified native build')
    p.add_argument('--m04-artifacts',type=Path,help='Package the separately rebuilt, hash/ABI/source-verified M04 library')
    p.add_argument('--onednn',type=Path,default=ROOT.parent/'b70-onednn-3.13-install')
    p.add_argument('--gptq-repo',type=Path,default=ROOT.parent/'intel-b70-qwen38-vllm-onednn')
    a=p.parse_args();out=a.output.resolve()
    if out.exists(): raise SystemExit('Fresh build evidence directory required')
    if subprocess.run(['docker','image','inspect',a.tag],capture_output=True).returncode==0:
        raise SystemExit('Candidate tag already exists; choose a new immutable candidate name')
    for image in (BUILDER,BASE): subprocess.run(['docker','image','inspect',image],check=True,stdout=subprocess.DEVNULL)
    out.mkdir(parents=True)
    state={'schema':1,'started_unix':time.time(),'builder_image':BUILDER,'base_image':BASE,'tag':a.tag,'commands':[],
           'source_sha256':{str(f.relative_to(ROOT)):sha(f) for d in ('exl3xpu','csrc','scripts','models','docker','tests')
                            for f in (ROOT/d).rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix not in ('.so','.log')}}
    def save(): (out/'build.json').write_text(json.dumps(state,indent=2)+'\n')
    def run(command,log):
        state['commands'].append(command);save()
        with (out/log).open('w') as stream: subprocess.run(command,check=True,stdout=stream,stderr=subprocess.STDOUT)
    try:
        if a.native_artifacts:
            native=a.native_artifacts.resolve();state['native_reused']=str(native)
        else:
            native=out/'native';native.mkdir()
            assert (a.onednn/'include/oneapi/dnnl/dnnl_sycl.hpp').is_file()
            run(['docker','run','--rm','--network','none','--memory','12g','--entrypoint','/bin/bash',
                 '-v',str(ROOT)+':/work:ro','-v',str(a.onednn.resolve())+':/opt/intel/oneapi/dnnl/latest:ro',
                 '-v',str(native)+':/results','-w','/work','-e','EXL3_OUT=/results/_C.so',
                 '-e','EXL3_BUILD_LOG=/results/compiler.log',BUILDER,'scripts/build_ext.sh'],'native-build.log')
        manifest=json.loads((native/'_C.so.manifest.json').read_text())
        assert manifest['torch_version']=='2.13.0+xpu' and manifest['torch_cxx11_abi'] is True
        assert sha(native/'_C.so')==manifest['library_sha256']
        for path,h in manifest['source_sha256'].items(): assert sha(ROOT/path)==h,path
        state['native_manifest']=manifest
        stage=ROOT/'.native-target';stage.mkdir(exist_ok=True)
        for file in ('_C.so','_C.so.manifest.json'): shutil.copyfile(native/file,stage/file)
        stage=ROOT/'.m04-target'
        if stage.exists(): shutil.rmtree(stage)
        stage.mkdir()
        if a.m04_artifacts:
            m04=a.m04_artifacts.resolve()
            receipt=json.loads((m04/'manifest.json').read_text())
            assert receipt['torch']=='2.13.0+xpu' and receipt['cxx11_abi'] is True
            assert sha(m04/'m04.so')==receipt['library_sha256']
            source=a.gptq_repo/'benchmarks/experiments/exl3-shared-kv-verify'
            for file in ('csrc/shared_kv_verification.cpp','patches/shared-kv-verification.patch'):
                assert sha(source/file)==receipt['source_sha256'][file],file
            state['m04_manifest']=receipt
            for file in ('m04.so','manifest.json'): shutil.copyfile(m04/file,stage/file)
            # Keep the independently reviewed sources with the immutable image.
            for file in ('csrc/shared_kv_verification.cpp','patches/shared-kv-verification.patch'):
                target=stage/file;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(source/file,target)
        stage=ROOT/'.target-integration';stage.mkdir(exist_ok=True)
        state['integration_sha256']={}
        for file in ('patch_mtp_format_guard.py','b70_mtp_policy.py'):
            source=a.gptq_repo/'docker/patches'/file;state['integration_sha256'][file]=sha(source)
            shutil.copyfile(source,stage/file)
        run(['docker','build','--build-arg','BASE_IMAGE='+BASE,'-f',str(ROOT/'docker/Dockerfile.migration-target'),
             '-t',a.tag,str(ROOT)],'image-build.log')
        state['image_id']=subprocess.check_output(['docker','image','inspect',a.tag,'--format','{{.Id}}'],text=True).strip()
        if a.m04_artifacts:
            probe="""import hashlib,pathlib,torch
p=pathlib.Path('/opt/exl3xpu/m04/m04.so')
assert hashlib.sha256(p.read_bytes()).hexdigest()==%r
torch.ops.load_library(str(p))
assert torch._C._dispatch_has_kernel_for_dispatch_key('b70_exl3_attention::shared_kv_verify_out','XPU')
print('PACKAGED_M04_CPU_IMPORT_PASS')""" % receipt['library_sha256']
            run(['docker','run','--rm','--network','none','--entrypoint','python',state['image_id'],
                 '-c',probe],'m04-image-import.log')
        state['status']='PASS'
    except BaseException as e:
        state['status']='FAIL';state['error']=repr(e);raise
    finally:
        state['finished_unix']=time.time();save()
    print(json.dumps({'status':state['status'],'image_id':state['image_id']}))

if __name__=='__main__': main()
