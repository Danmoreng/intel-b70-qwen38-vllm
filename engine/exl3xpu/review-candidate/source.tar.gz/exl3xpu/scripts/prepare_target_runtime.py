"""Remove the GPTQ-specific attention adapter at its reviewed import boundary."""
from pathlib import Path
path = Path('/opt/venv/lib/python3.12/site-packages/vllm/_xpu_ops.py')
source = path.read_text()
old = 'from b70_attention import flash_attn_varlen_func'
new = 'from vllm_xpu_kernels.flash_attn_interface import flash_attn_varlen_func'
if source.count(old) != 1:
    raise RuntimeError('Unknown target XPU attention import; do not inherit GPTQ routing')
source = source.replace(old, new, 1)
compile(source, str(path), 'exec')
path.write_text(source)
print('EXL3 initial port: native XPU attention restored; GPTQ adapter not imported')
