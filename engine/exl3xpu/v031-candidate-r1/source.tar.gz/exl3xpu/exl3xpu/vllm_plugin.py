"""
vLLM out-of-tree quantization plugin: EXL3 (exllamav3 trellis) weights on Intel XPU.

Registered via the `vllm.general_plugins` entry point, so every vLLM process (API server,
engine core, workers) imports it before model construction.
"""
from __future__ import annotations
import json
import hashlib
import os
import re
import weakref
from typing import Any

import torch
from torch.nn import Parameter
from vllm.distributed import get_tensor_model_parallel_world_size

from vllm.logger import init_logger
from vllm.model_executor.layers.linear import LinearBase, LinearMethodBase, UnquantizedLinearMethod
from vllm.model_executor.layers.quantization import register_quantization_config
from vllm.model_executor.layers.quantization.base_config import QuantizationConfig
from vllm.model_executor.layers.vocab_parallel_embedding import ParallelLMHead

logger = init_logger("vllm.exl3xpu")
from .checkpoint import normalize_key as _norm_key, inventory, validate_exl3_environment

# vLLM fused module -> checkpoint constituents
FUSED = {
    "gate_up_proj": ["gate_proj", "up_proj"],
    "qkv_proj": ["q_proj", "k_proj", "v_proj"],
    "in_proj_qkvz": ["in_proj_qkv", "in_proj_z"],
    "in_proj_ba": ["in_proj_b", "in_proj_a"],
}
QKV_IDS = {"q": 0, "k": 1, "v": 2}
CB_IDS = {"3inst": 0, "mcg": 1, "mul1": 2}


@register_quantization_config("exl3")
class Exl3Config(QuantizationConfig):

    def __init__(self, bits: float, head_bits: int, codebook: str, storage: dict | None = None,
                 mtp_bits: int | None = None):
        super().__init__()
        validate_exl3_environment(os.environ)
        logger.info("EXL3 MTP quantization path: checkpoint-native EXL3; GPTQ draft overrides disabled")
        self.bits = bits
        self.mtp_bits = int(mtp_bits or bits)
        self.head_bits = head_bits
        self.codebook = codebook
        self.storage = storage or {}

    def __repr__(self):
        return f"Exl3Config(bits={self.bits}, head_bits={self.head_bits}, codebook={self.codebook})"

    def get_name(self):
        return "exl3"

    def get_supported_act_dtypes(self):
        return [torch.float16, torch.bfloat16]

    @classmethod
    def get_min_capability(cls) -> int:
        return 0

    @staticmethod
    def get_config_filenames() -> list[str]:
        return []

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "Exl3Config":
        return cls(bits=config.get("bits", 4), head_bits=config.get("head_bits", 6),
                   codebook=config.get("codebook", "mul1"), mtp_bits=config.get("mtp_bits"))

    def _model_file(self, model_name, fname, revision):
        path = os.path.join(model_name, fname)
        if os.path.isfile(path):
            return path
        try:
            from huggingface_hub import hf_hub_download
            return hf_hub_download(model_name, fname, revision=revision)
        except Exception:
            return None

    def maybe_update_config(self, model_name: str, hf_config=None, revision=None):
        # Which modules are EXL3 is decided by the checkpoint itself: a module is EXL3 iff the weight
        # index has '<module>.trellis'. (quantization_config.json's tensor_storage omits the MTP head.)
        idx_path = self._model_file(model_name, "model.safetensors.index.json", revision)
        qc_path = self._model_file(model_name, "quantization_config.json", revision)
        qc = {}
        if qc_path:
            with open(qc_path) as f:
                qc = json.load(f)
        if not idx_path:
            raise RuntimeError("exl3: authoritative model.safetensors.index.json is required")
        with open(idx_path) as f:
            wmap = json.load(f)["weight_map"]
        self.expected_inventory = inventory(wmap, qc, bits=int(self.bits), head_bits=self.head_bits,
                                            mtp_bits=self.mtp_bits, codebook=self.codebook)
        self.storage = {v['canonical']:v['bits'] for v in self.expected_inventory}
        logger.info("exl3: %d EXL3 modules (%d in MTP head)", len(self.storage),
                    sum(1 for k in self.storage if k.startswith("mtp.")))

    def _bits_for(self, prefix: str) -> int | None:
        parts = prefix.split(".")
        if "visual" in parts or "vision_tower" in parts:
            return None
        key = _norm_key(prefix)
        if not self.storage:
            if key.endswith("in_proj_ba"):
                return None
            return self.head_bits if key == "lm_head" else int(self.bits)
        base, _, leaf = key.rpartition(".")
        members = FUSED.get(leaf, [leaf])
        names = [f"{base}.{p}" if base else p for p in members]
        bits = [self.storage.get(n) for n in names]
        if all(b is None for b in bits):
            return None
        assert all(b == bits[0] for b in bits), f"exl3: mixed quant in fused module {prefix}: {bits}"
        return bits[0]

    def get_quant_method(self, layer: torch.nn.Module, prefix: str):
        if isinstance(layer, LinearBase):
            bits = self._bits_for(prefix)
            if bits is None:
                return UnquantizedLinearMethod()
            return Exl3LinearMethod(self, bits, prefix)
        if isinstance(layer, ParallelLMHead):
            bits = self._bits_for(prefix)
            if bits is None:
                return None
            return Exl3LinearMethod(self, bits, prefix)
        return None


class Exl3LinearMethod(LinearMethodBase):

    def __init__(self, config: Exl3Config, bits: int, prefix: str = ""):
        self.config = config
        self.K = int(bits)
        self.cb = CB_IDS[config.codebook]
        self.prefix = prefix

    def create_weights(self, layer, input_size_per_partition, output_partition_sizes, input_size,
                       output_size, params_dtype, **extra_weight_attrs):
        k = input_size_per_partition
        n = sum(output_partition_sizes)
        if get_tensor_model_parallel_world_size() != 1:
            raise NotImplementedError("exl3: tensor parallel sharding is not qualified (TP must be 1)")
        if k != input_size or n != (output_size if not isinstance(layer, ParallelLMHead) else n):
            raise NotImplementedError("exl3: tensor parallel sharding not supported yet (use DP)")
        if k % 128 != 0 or not output_partition_sizes or any(s<=0 or s%128 for s in output_partition_sizes):
            raise ValueError(f"exl3: dims must be positive multiples of 128 (k={k}, n={output_partition_sizes})")
        K = self.K
        layer.exl3_sizes = list(output_partition_sizes)
        layer.exl3_offsets = [sum(output_partition_sizes[:i]) for i in range(len(output_partition_sizes) + 1)]
        layer.exl3_groups = set()
        layer.exl3_loaded_shards = {name:set() for name in ('trellis','suh','svh')}
        layer.exl3_codebook_loaded = False
        layer.exl3_K = K
        layer.exl3_cb = self.cb
        layer_ref = weakref.ref(layer)

        def reg(name, tensor, loader):
            p = Parameter(tensor, requires_grad=False)
            p.weight_loader = loader
            layer.register_parameter(name, p)

        reg("trellis", torch.empty((k // 16, n // 16, 16 * K), dtype=torch.int16), self._load_trellis(layer))
        reg("suh", torch.empty((len(output_partition_sizes), k), dtype=torch.float16), self._load_suh(layer))
        reg("svh", torch.empty((n,), dtype=torch.float16), self._load_svh(layer))
        if self.config.codebook != "3inst":
            def load_codebook(p,w,*a,**kw):
                layer = layer_ref()
                if layer is None:
                    raise RuntimeError(f'exl3: codebook loader owner was released: {self.prefix}')
                if w.shape != torch.Size([]) or w.dtype != torch.int32:
                    raise ValueError(f"exl3: invalid codebook marker {self.prefix}: {w.shape}/{w.dtype}")
                p.data.copy_(w)
                layer.exl3_codebook_loaded = True
            reg(self.config.codebook, torch.empty((), dtype=torch.int32), load_codebook)

    @staticmethod
    def _shards(layer, loaded, sid=None) -> list[int]:
        if sid is None:
            sid = getattr(loaded, "shard_id", None)
        if sid is None:
            return list(range(len(layer.exl3_sizes)))
        if isinstance(sid, str):
            return [QKV_IDS[sid]]
        if isinstance(sid, int):
            return [sid]
        return list(sid)

    def _range(self, layer, loaded, sid=None):
        s = self._shards(layer, loaded, sid)
        if not s or any(not isinstance(i,int) or i<0 or i>=len(layer.exl3_sizes) for i in s):
            raise ValueError(f"exl3: invalid shard IDs {s} for {self.prefix}")
        if s != list(range(s[0], s[-1]+1)):
            raise ValueError(f"exl3: shards must be ordered and contiguous: {s}")
        return s, layer.exl3_offsets[s[0]], layer.exl3_offsets[s[-1] + 1]

    def _load_trellis(self, layer):
        layer_ref = weakref.ref(layer)
        def f(param, w, sid=None):
            layer = layer_ref()
            if layer is None:
                raise RuntimeError(f'exl3: trellis loader owner was released: {self.prefix}')
            s, a, b = self._range(layer, w, sid)
            if w.dtype!=torch.int16 or tuple(w.shape)!=(param.shape[0],(b-a)//16,param.shape[-1]):
                raise ValueError(f"exl3: trellis shape/bits mismatch {self.prefix}: {tuple(w.shape)}/{w.dtype} vs {tuple(param.shape)}")
            if set(s) & layer.exl3_loaded_shards['trellis']:
                raise ValueError(f"exl3: duplicate trellis shards {s}: {self.prefix}")
            param.data[:, a // 16: b // 16].copy_(w)
            layer.exl3_loaded_shards['trellis'].update(s)
            layer.exl3_groups.add(tuple(s))
        return f

    def _load_suh(self, layer):
        layer_ref = weakref.ref(layer)
        def f(param, w, sid=None):
            layer = layer_ref()
            if layer is None:
                raise RuntimeError(f'exl3: suh loader owner was released: {self.prefix}')
            s, _, _ = self._range(layer, w, sid)
            if tuple(w.shape) != (param.shape[1],):
                raise ValueError(f"exl3: suh shape mismatch for {self.prefix}: {w.shape}")
            if set(s) & layer.exl3_loaded_shards['suh']:
                raise ValueError(f"exl3: duplicate suh shards {s}: {self.prefix}")
            for i in s:
                param.data[i].copy_(w)
            layer.exl3_loaded_shards['suh'].update(s)
        return f

    def _load_svh(self, layer):
        layer_ref = weakref.ref(layer)
        def f(param, w, sid=None):
            layer = layer_ref()
            if layer is None:
                raise RuntimeError(f'exl3: svh loader owner was released: {self.prefix}')
            s, a, b = self._range(layer, w, sid)
            if tuple(w.shape) != (b-a,):
                raise ValueError(f"exl3: svh shape mismatch for {self.prefix}: {w.shape}")
            if set(s) & layer.exl3_loaded_shards['svh']:
                raise ValueError(f"exl3: duplicate svh shards {s}: {self.prefix}")
            param.data[a:b].copy_(w)
            layer.exl3_loaded_shards['svh'].update(s)
        return f

    def process_weights_after_loading(self, layer):
        expected_shards=set(range(len(layer.exl3_sizes)))
        for name,loaded in layer.exl3_loaded_shards.items():
            if loaded != expected_shards:
                raise ValueError(f"exl3: incomplete {name} shards for {self.prefix}: {sorted(loaded)} != {sorted(expected_shards)}")
        if self.config.codebook!='3inst' and not layer.exl3_codebook_loaded:
            raise ValueError(f"exl3: missing codebook marker for {self.prefix}")
        groups = sorted(layer.exl3_groups)
        covered = [i for g in groups for i in g]
        assert covered == list(range(len(layer.exl3_sizes))), f"exl3: incomplete shards {groups}"
        dev = layer.trellis.device
        suh = torch.stack([layer.suh.data[g[0]] for g in groups]).contiguous()
        bounds = [layer.exl3_offsets[g[0]] for g in groups] + [layer.exl3_offsets[-1]]
        n = bounds[-1]
        shard_of_nb = torch.empty(n // 128, dtype=torch.int32)
        for gi in range(len(groups)):
            shard_of_nb[bounds[gi] // 128: bounds[gi + 1] // 128] = gi
        layer.suh = Parameter(suh, requires_grad=False)
        layer.exl3_shard_of_nb = shard_of_nb.to(dev)
        layer.exl3_bounds = bounds
        key=_norm_key(self.prefix)
        base,_,leaf=key.rpartition('.')
        members=[f'{base}.{p}' if base else p for p in FUSED.get(leaf,[leaf])]
        # GDN's combined q/k/v source shares one Hadamard transform; z has its own.
        expected_groups=[(0,1,2),(3,)] if leaf=='in_proj_qkvz' else [(i,) for i in range(len(members))]
        if self.prefix and groups!=expected_groups:
            raise ValueError(f"exl3: unexpected fused source groups for {self.prefix}: {groups} != {expected_groups}")
        for member in members:
            if self.config.storage and self.config.storage.get(member)!=self.K:
                raise ValueError(f"exl3: loaded unexpected module/bit width {member}/{self.K}")
        layer.exl3_loader_report={'prefix':self.prefix,'members':members,'bits':self.K,
                                  'shapes':{name:list(getattr(layer,name).shape) for name in ('trellis','suh','svh')},
                                  'groups':[list(g) for g in groups],'bounds':bounds,
                                  'shard_of_nb_counts':[(bounds[i+1]-bounds[i])//128 for i in range(len(groups))],
                                  'loaded_shards':{name:sorted(v) for name,v in layer.exl3_loaded_shards.items()},
                                  'codebook':self.config.codebook,'status':'PASS'}
        if isinstance(layer, ParallelLMHead) and os.environ.get("EXL3_DRAFT_VOCAB") and _spec_is_mtp():
            _build_draft_head(layer, os.environ["EXL3_DRAFT_VOCAB"])
        cb = self.cb
        if hasattr(layer, "mcg"):
            cb = 1
        elif hasattr(layer, "mul1"):
            cb = 2
        layer.exl3_cb = cb
        # decide the backend once, outside any traced code: the all-C++ op when the ESIMD library has it
        from . import ops
        E = ops._get_esimd()
        layer.exl3_cpp = bool(E) and hasattr(E, "linear") and bool(E.exl3_supported(layer.exl3_K, cb))

    def apply(self, layer, x, bias=None):
        from . import ops
        if layer.exl3_cpp:
            y = torch.ops.exl3xpu_C.linear(x, layer.trellis, layer.suh, layer.svh, layer.exl3_shard_of_nb,
                                           layer.exl3_bounds, layer.exl3_K, layer.exl3_cb,
                                           ops.SMALL_M_MAX, ops.RECON_SLICE_N)
        else:
            y = ops._exl3_linear_py(x, layer.trellis, layer.suh, layer.svh, layer.exl3_shard_of_nb,
                                    layer.exl3_bounds, layer.exl3_K, layer.exl3_cb)
        if bias is not None:
            y = y + bias
        return y

    # lm_head (ParallelLMHead) path
    def embedding(self, layer, input_):
        raise NotImplementedError("exl3: quantized input embeddings are not supported")


# ------------------------------------------------------------------------------------------------
# Pruned-vocabulary draft head for MTP speculative decoding.
# The drafter proposes tokens from a subset of 128-token blocks (EXL3 lm_head columns can only be
# sliced by whole 128-column Hadamard blocks); the target still verifies with the full lm_head, so
# generated text is unchanged. Enabled by EXL3_DRAFT_VOCAB=<draft_vocab.json> (see scripts/draft_vocab.py).

def _spec_is_mtp():
    """The pruned draft head only serves the MTP drafter; with another drafter (dspark, dflash) or none it is
    dead weight in VRAM, so skip it."""
    try:
        from vllm.config import get_current_vllm_config
        sc = get_current_vllm_config().speculative_config
    except Exception:
        return True
    return sc is not None and "mtp" in str(getattr(sc, "method", "")).lower()


def _build_draft_head(layer, path):
    with open(path) as f:
        spec = json.load(f)
    n_total_blocks = layer.svh.shape[0] // 128
    ids=spec['blocks']
    if not ids or any(type(i) is not int or i<0 or i>=n_total_blocks for i in ids) or len(set(ids))!=len(ids):
        raise ValueError(f'exl3: draft vocabulary contains empty/invalid/duplicate blocks: {path}')
    blocks = torch.tensor(ids, dtype=torch.long)
    dev = layer.trellis.device
    tiles = (blocks[:, None] * 8 + torch.arange(8)[None, :]).flatten().to(dev)
    trellis = layer.trellis.data.index_select(1, tiles).contiguous()
    svh = layer.svh.data.view(-1, 128).index_select(0, blocks.to(dev)).flatten().contiguous()
    idx = (blocks[:, None] * 128 + torch.arange(128)[None, :]).flatten().to(dev)
    layer.exl3_draft = dict(trellis=trellis, svh=svh, idx=idx,
                            shard=torch.zeros(len(blocks), dtype=torch.int32, device=dev),
                            bounds=[0, len(blocks) * 128])
    logger.info("exl3: MTP draft head uses %d of %d vocab blocks (%.1f%% of lm_head)",
                len(blocks), n_total_blocks, 100.0 * len(blocks) / n_total_blocks)


def _patch_mtp_draft_logits():
    try:
        from vllm.model_executor.models import qwen3_5_mtp
    except Exception:
        return
    cls = qwen3_5_mtp.Qwen3_5MTP
    if getattr(cls, "_exl3_patched", False):
        return
    orig = cls.compute_logits

    def compute_logits(self, hidden_states, spec_step_idx: int = 0):
        lm = self.lm_head
        d = getattr(lm, "exl3_draft", None)
        if d is None:
            return orig(self, hidden_states, spec_step_idx)
        from . import ops
        sub = torch.ops.exl3xpu_C.linear(hidden_states, d["trellis"], lm.suh, d["svh"], d["shard"], d["bounds"],
                                         lm.exl3_K, lm.exl3_cb, ops.SMALL_M_MAX, ops.RECON_SLICE_N)
        logits = hidden_states.new_full((hidden_states.shape[0], lm.svh.shape[0]), float("-inf"))
        logits.index_copy_(1, d["idx"], sub)
        return logits[:, : self.config.vocab_size]

    cls.compute_logits = compute_logits
    cls._exl3_patched = True


def register():
    """vllm.general_plugins entry point (runs in every vLLM process)."""
    with open(__file__,'rb') as source:
        digest=hashlib.file_digest(source,'sha256').hexdigest()
    logger.info('EXL3 plugin registered pid=%d source=%s sha256=%s',os.getpid(),__file__,digest)
    if os.environ.get("EXL3_DRAFT_VOCAB"):
        _patch_mtp_draft_logits()
    if os.environ.get('EXL3_TARGET_RUNTIME') == 'vllm031':
        from . import target_runtime
        target_runtime.install()
    elif os.environ.get("EXL3_VLLM_PATCHES", "1") != "0":
        from . import vllm_patches
        vllm_patches.apply_all()
    from . import loader_audit
    loader_audit.install()
    from . import cache_retirement
    cache_retirement.install()
    from . import migration_trace
    migration_trace.install()
    return None
