"""Install the EXL3 format policy on the exact pristine vLLM 0.31 boundary."""
import hashlib
from pathlib import Path

root = Path('/opt/venv/lib/python3.12/site-packages/vllm')
native = root/'_xpu_ops.py'
assert hashlib.sha256(native.read_bytes()).hexdigest() == '713f181dcfc72814e227f9e1ffe8878b03cbfe524b0be60b3fc261bdb76cd448'
assert 'from vllm_xpu_kernels.flash_attn_interface import flash_attn_varlen_func' in native.read_text()
path = root/'model_executor/models/qwen3_5_mtp.py'
source = path.read_text()
assert hashlib.sha256(source.encode()).hexdigest() == 'd206addc79b7d01aabe54be57a6610b897a88d1130df51d39b3975b53599110b'

def replace_once(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new, 1)

replace_once('import torch\n', 'import torch\nfrom .b70_mtp_policy import resolve_mtp_policy\n# B70_MTP_FORMAT_GUARD_V031\n')
replace_once('        quant_config = vllm_config.quant_config\n',
             '        quant_config = vllm_config.quant_config\n'
             '        self._b70_mtp_policy = resolve_mtp_policy(quant_config, model_config.hf_config)\n'
             '        logger.info("B70 MTP quantization path: %s", self._b70_mtp_policy.description)\n')
replace_once('if quant_config and quant_config.get_name() not in ("modelopt_fp4",):',
             'if self._b70_mtp_policy.is_gptq:')
compile(source, str(path), 'exec')
path.write_text(source)
(path.parent/'b70_mtp_policy.py').write_bytes(Path('/tmp/exl3-integration/b70_mtp_policy.py').read_bytes())
print('EXL3 0.31: native XPU attention; checkpoint-native EXL3 MTP policy; no inherited GPTQ patches')
